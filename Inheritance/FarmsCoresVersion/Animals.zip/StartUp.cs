﻿using System;
using FarmsCoresVersion.Core;

namespace FarmsCoresVersion
{
    class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
