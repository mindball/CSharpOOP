﻿using Animals.Core;
using System;
using System.Collections.Generic;
using System.Linq;

class Startup
{
    static void Main()
    {
        Engine engine = new Engine();
        engine.Run();
    }
}

