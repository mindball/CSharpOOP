﻿namespace ExplicitInterfaces.Contracts
{
    interface IResindent
    {
        string Name { get; }       

        int Age { get; }

        string GetName();
    }
}
