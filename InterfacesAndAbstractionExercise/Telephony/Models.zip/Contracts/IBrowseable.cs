﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony.Contracts
{
    public interface IBrowseable
    {
        string Browse(string url);
    }
}
