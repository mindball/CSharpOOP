﻿namespace PlayersAndMonsters
{
    using System;

    using Core;
    using Core.Contracts;
    using Core.Factories;
    using Core.Factories.Contracts;
    using Repositories;
    using Repositories.Contracts;
    using IO;
    using IO.Contracts;
    using Models.BattleFields;
    using Models.BattleFields.Contracts;

    public class StartUp
    {
        //public static ICardRepository cardRepository;
        //public static IPlayerRepository playerRepository;
        //public static IPlayerFactory createPlayer;
        //public static ICardFactory createCard;
        //public static BattleField battleField;

        //static StartUp()
        //{
        //    cardRepository = new CardRepository();
        //    playerRepository = new PlayerRepository();
        //    createPlayer = new PlayerFactory();
        //    createCard = new CardFactory();
        //    battleField = new BattleField();
        //}
        public static void Main(string[] args)
        {
            //IManagerController manager = new ManagerController(
            //        cardRepository,
            //        playerRepository,
            //        createPlayer,
            //        createCard,
            //        battleField
            //        );

            //string input = Console.ReadLine();
            //string message = null;
            //while (true)
            //{
            //    string[] str = input.Split();
            //    if (str.Length > 1)
            //    {
            //        switch (str[0])
            //        {
            //            case "AddPlayer":
            //                message = manager.AddPlayer(str[1], str[2]);
            //                break;
            //            case "AddCard":
            //                message = manager.AddCard(str[1], str[2]);
            //                break;
            //            case "AddPlayerCard":
            //                message = manager.AddPlayerCard(str[1], str[2]);
            //                break;
            //            case "Fight":
            //                message = manager.Fight(str[1], str[2]);
            //                break;
            //        }
            //    }
            //    else
            //    {
            //        message = manager.Report();
            //    }

            //    Console.WriteLine(message);
            //    input = Console.ReadLine();
            //}

            IReader reader = new ConsoleReader();
            IWriter writer = new ConsoleWriter();

            ICardRepository cardRepository = new CardRepository();
            IPlayerRepository playerRepository = new PlayerRepository();
            IPlayerFactory createPlayer = new PlayerFactory();
            ICardFactory createCard = new CardFactory();
            BattleField battleField = new BattleField();

            IManagerController manager = new ManagerController(
                cardRepository,
                playerRepository,
                createPlayer,
                createCard,
                battleField);

            IEngine engine = new Engine(reader, writer, manager);
            engine.Run();
        }                                     
    }                                          
}