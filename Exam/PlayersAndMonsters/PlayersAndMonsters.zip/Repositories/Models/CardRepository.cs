﻿

namespace PlayersAndMonsters.Repositories.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    using PlayersAndMonsters.Models.Cards.Contracts;
    using PlayersAndMonsters.Models.Players.Contracts;
    using PlayersAndMonsters.Repositories.Contracts;

    class CardRepository : ICardRepository
    {
        private List<ICard> cards = new List<ICard>();

        public int Count => this.cards.Count;

        public IReadOnlyCollection<ICard> Cards => this.cards.AsReadOnly();

        public void Add(ICard card)
        {
            if (card is null)
            {
                throw new ArgumentException("Card cannot be null");
            }

            if (Cards.Any(
                x => x.Name.Equals(card.Name)))
            {
                new ArgumentException($"Card {card.Name} already exists!");
            }

            this.cards.Add(card);
        }
      

        public ICard Find(string name)
        {
            return this.cards.FirstOrDefault(x => x.Name.Equals(name));
        }

        public bool Remove(ICard card)
        {
            this.cards.Remove(card);
            //TODO: check return 
            return true;
        }
    }
}
